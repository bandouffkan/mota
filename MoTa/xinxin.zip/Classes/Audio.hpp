//
//  Audio.hpp
//  MoTa
//
//  Created by xcode31 on 16/6/29.
//
//

#ifndef Audio_hpp
#define Audio_hpp

#include "SimpleAudioEngine.h"
#include "cocos2d.h"
using namespace CocosDenshion;

class Audio{
public:
    enum E_voice{
        SWORD,
        GETS,
        OPENDOOR,
        LORDSHOW,
        WIN,
        WINAWARD,
        BUYSUCCE,
        BUYFAIL,
        LEAVENPC,
        YESNPC,
        BGM1,
        BGM2,
        BGM3,
        LASTWIN,
    };
    Audio();
    static Audio* getInstance();
    void release();
    void playSound(int type);
    void playBGM(int type);
    void setSoundType(bool type);
    void setBGMType(bool type);
    bool isOpenSound();
    bool isOpenBGM();
private:
    static Audio* audio;
    bool SoundState;
    bool BGMState;
    E_voice BGMType;
};

#endif /* Audio_hpp */
