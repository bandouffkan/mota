//
//  Audio.cpp
//  MoTa
//
//  Created by xcode31 on 16/6/29.
//
//

#include "Audio.hpp"
USING_NS_CC;

Audio::Audio(){
    SoundState = true;
    BGMState = true;
}
Audio* Audio::audio = NULL;
Audio* Audio::getInstance(){
    if(audio == NULL){
        audio = new Audio();
        return audio;
    }else{
        return audio;
    }
}
void Audio::playSound(int type){
    if (this->isOpenSound()){
        SimpleAudioEngine::getInstance()->stopAllEffects();
        switch (type)
        {
            case SWORD:
                SimpleAudioEngine::getInstance()->playEffect("sounds/sword2.mp3");
                break;
            case GETS:
                SimpleAudioEngine::getInstance()->playEffect("sounds/gets.mp3");
                break;
            case OPENDOOR:
                SimpleAudioEngine::getInstance()->playEffect("sounds/openDoor.mp3");
                break;
            case LORDSHOW:
                SimpleAudioEngine::getInstance()->playEffect("sounds/lordShow.mp3");
                break;
            case WIN:
                SimpleAudioEngine::getInstance()->playEffect("sounds/win.mp3");
                break;
            case WINAWARD:
                SimpleAudioEngine::getInstance()->playEffect("sounds/winAward.mp3");
                break;
            case BUYSUCCE:
                SimpleAudioEngine::getInstance()->playEffect("sounds/buySucceed.mp3");
                break;
            case BUYFAIL:
                SimpleAudioEngine::getInstance()->playEffect("sounds/buyFail.mp3");
                break;
            case LEAVENPC:
                SimpleAudioEngine::getInstance()->playEffect("sounds/leaveNPC.mp3");
                break;
            case YESNPC:
                SimpleAudioEngine::getInstance()->playEffect("sounds/yes.mp3");
                break;
        }
    }
}
void Audio::playBGM(int type)
{
    if (this->isOpenBGM())
    {
        if(BGMType==type)
            return;
        SimpleAudioEngine::getInstance()->stopBackgroundMusic();
        SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(0.5);
        switch (type)
        {
            case BGM1:
                SimpleAudioEngine::getInstance()->playBackgroundMusic("sounds/bgm.mp3",true);
                break;
            case BGM2:
                SimpleAudioEngine::getInstance()->playBackgroundMusic("sounds/bgmSky.mp3",true);
                break;
            case BGM3:
                SimpleAudioEngine::getInstance()->playBackgroundMusic("sounds/bgmMagma.mp3",true);
                break;
            case LASTWIN:
                SimpleAudioEngine::getInstance()->playEffect("sounds/lastWin.mp3");
                break;
        }
        BGMType = (E_voice)type;
    }
}
void Audio::setSoundType(bool type){
    SoundState = type;
}
void Audio::setBGMType(bool type)
{
    BGMState = type;
}
bool Audio::isOpenBGM()
{
    return BGMState;
}
bool Audio::isOpenSound()
{
    return SoundState;
}

