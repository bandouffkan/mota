#include "GameScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "PropsFace.hpp"
USING_NS_CC;

using namespace cocostudio::timeline;
ControlLayer* GameScene::controlLayer = NULL;
Scene* GameScene::createScene()
{
    auto scene = Scene::create();
    
    auto layer = GameScene::create();

    scene->addChild(layer);

    return scene;
}
Scene* GameScene::createArcScene(int num)
{
    auto scene = Scene::create();
    
    auto layer = GameScene::create();

    scene->addChild(layer);
    
    layer->controlLayer->readArchive(num);

    return scene;
}
bool GameScene::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    
    //背景
    auto bg_sp = Sprite::create("bg.png");
    auto bg_size = bg_sp->getContentSize();
    bg_size = bg_size * 2;
    int bg_x = ceil(VISIBSIZE.width/bg_size.width);
    int bg_y = ceil(VISIBSIZE.height/bg_size.height);
    for(int y=0;y<bg_y;y++)
    {
        for(int x=0;x<bg_x;x++)
        {
            auto sp = Sprite::create("bg.png");
            sp->setScale(2);
            addChild(sp);
            sp->setPosition(x*bg_size.width+bg_size.width/2,y*bg_size.height+bg_size.height/2);
        }
    }
    
    controlLayer = ControlLayer::create();
    addChild(controlLayer);
    
    //道具里钥匙UI
    auto propsFace = PropsFace::create();
    controlLayer->addChild(propsFace,10);
    controlLayer->propsFace = propsFace;
    propsFace->setPosition(VISIBSIZE.width*0.83,VISIBSIZE.height*0.7);
    
    auto stairFlight = StairFlight::create();
    controlLayer->addChild(stairFlight,10);
    controlLayer->stairFlight = stairFlight;
    stairFlight->setPosition(0,0);
    stairFlight->setVisible(false);
    
    return true;
}
