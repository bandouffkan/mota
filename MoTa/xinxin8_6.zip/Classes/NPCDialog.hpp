//
//  NPCDialog.hpp
//  MoTa
//
//  Created by xcode31 on 16/7/6.
//
//

#ifndef NPCDialog_hpp
#define NPCDialog_hpp

#include "cocos2d.h"
#include "GameConstants.h"
USING_NS_CC;

class NPCDialog : public Node
{
public:
    //初始化方法
    bool init();
    CREATE_FUNC(NPCDialog);
};

#endif /* NPCDialog_hpp */
