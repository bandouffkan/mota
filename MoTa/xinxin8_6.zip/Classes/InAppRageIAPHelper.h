//
//  InAppRageIAPHelper.hpp
//  MagicTower
//
//  Created by xcode31 on 16/3/3.
//
//

#ifndef InAppRageIAPHelper_hpp
#define InAppRageIAPHelper_hpp

#import <Foundation/Foundation.h>
#import "IAPHelper.h"

@interface InAppRageIAPHelper : IAPHelper {
    
}

+ (InAppRageIAPHelper *) sharedHelper;

@end

#endif /* InAppRageIAPHelper_hpp */
