//
//  NPCDialog.cpp
//  MoTa
//
//  Created by xcode31 on 16/7/6.
//
//

#include "NPCDialog.hpp"

bool NPCDialog::init()
{
    if (!Node::init())
    {
        return false;
    }
    
    
    
    return true;
}